#include "quicksort.h"

void Quicksort1(int v[], int n) {

}

void Quicksort2(int v[], int n) {
  
}

void Quicksort3(int v[], int n) {
  
}

void QuicksortH1(int v[], int n) {
  
}

void QuicksortH2(int v[], int n) {
  
}

void QuicksortH3(int v[], int n) {
  
}
